#ifndef mergeSort_h
#define mergeSort_h

void merge(double tab[], int left, int middle, int right);
void mergeSortFunc(double tab[], int left, int right);
void mergeSort(double tab[], int left, int right, int n);
void resetBubble();
int ileOperacjiMerge();

#endif