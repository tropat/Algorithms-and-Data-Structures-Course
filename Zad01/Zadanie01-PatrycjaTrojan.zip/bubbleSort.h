#ifndef bubbleSort_h
#define bubbleSort_h

void bubbleSort(double tab[], int n);
void resetMerge();
int ileOperacjiBubble();

#endif